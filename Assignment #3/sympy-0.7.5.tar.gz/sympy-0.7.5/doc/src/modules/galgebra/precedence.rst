Precedence for Geometric Algebra
================================

.. module:: sympy.galgebra.precedence

Function Reference
------------------

.. autofunction:: add_paren

.. autofunction:: contains_interval

.. autofunction:: define_precedence

.. autofunction:: GAeval

.. autofunction:: parse_line

.. autofunction:: parse_paren

.. autofunction:: sub_paren

.. autofunction:: unparse_paren
