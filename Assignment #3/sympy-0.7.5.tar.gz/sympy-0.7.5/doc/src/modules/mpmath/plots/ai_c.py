# Airy function Ai(z) in the complex plane
cplot(airyai, [-8,8], [-8,8], points=50000)